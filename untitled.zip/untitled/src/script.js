//Array(Arreglo) para las imagenes, aqui van a poder poner las imagenes//
// de cada uno (ES INDIVIDUAL) //

const imagenes = [
  "https://plus.unsplash.com/premium_photo-1691367279293-f82232361dae?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
"https://images.unsplash.com/photo-1537274942065-eda9d00a6293?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
"https://images.unsplash.com/photo-1654463313125-20ac01f54613?q=80&w=987&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
"https://images.unsplash.com/photo-1581655353466-d5ad6765dd37?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
"https://images.unsplash.com/photo-1742392133846-a8b416e81661?q=80&w=1094&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
];

// Selección de elementos //

const boton = document.getElementById("btn-cambiar");
const imageCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

let indice = 0;

boton.addEventListener("click", () => {
  indice++;

  if (indice >= imagenes.length) {
    indice = 0;
  }

  // Cambiar la imagen
  imageCard.src = imagenes[indice];
  textoCard.textContent = Imagen ${indice + 1} de ${imagenes.length};
});