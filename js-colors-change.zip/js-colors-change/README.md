# JS-COLORS CHANGE

A Pen created on CodePen.

Original URL: [https://codepen.io/JUAN-DANIEL-ELIASGUERRERO/pen/bNVzGQw](https://codepen.io/JUAN-DANIEL-ELIASGUERRERO/pen/bNVzGQw).

