//desafio 1//

document.getElementById(id="btn-titulo").addEventListener("click",()=>
                                                          {
  const titulo = document.getElementById("titulo");
  titulo.textContent="¡J U A N    E L I A S!";
}       
                                                          );


// Desafío 2 getElementsByClassName//
document.getElementById("btn-cajas").addEventListener("click", () => {
  const cajas = document.getElementsByClassName("caja");
  for (let i = 0; i < cajas.length; i++) {
    cajas[i].style.backgroundColor = "#27C2F5";
  }
});   
  
//desafio 3 querySelector//
document.getElementById("btn-primera").addEventListener("click", () => {
  let primeraCaja = document.querySelector(".caja");
  if (primeraCaja) {
    primeraCaja.style.backgroundColor = "green";
  }
});
document.getElementById("btn-bordes").addEventListener("click", () => {
  let todasLasCajas = document.querySelectorAll(".caja");
  todasLasCajas.forEach(caja => {
    caja.style.border = "5px solid #235235"; 
  });
});